class snapshot:

    def __init__(self, snapshot):
        self.linesvalues = snapshot

    def getvalues(self):
        return self.linesvalues