=================================================================================

		Práctica 1: 	Algoritmos de Línea
			- Álvaro López García

=================================================================================

Hola,

Escribo este archivo de texto sólo para comentar un par de detalles sobre mi implementación de la práctica 1. El lenguaje escogido en mi caso ha sido Python y la herramienta gráfica empleada ha sido la librería Tkinter.

Todos los algoritmos están implementados en el mismo proyecto, y cada línea que se pinta puede dibujarse con un algoritmo distinto si así se quisiese.

Como extras añadidos, hemos de decir que el programa cuenta con la posibilidad de redimensionar el tamaño de píxel de las lineas en tiempo real, pintarlas en distintos colores, guardar dos colores como color primario y secundario respectivamente, seleccionar las lineas, cambiar de color, y también tiene implementada una versión un poco rudimentaria de deshacer (Control Z) y rehacer (Control Y).

He de mencionar también, que la implementación del algoritmo de Bresenham la he sacado de una página web (http://tech-algorithm.com/articles/drawing-line-using-bresenham-algorithm/). Lo hice así ya que esta implementación me pareció mucho mas ingeniosa y eficiente que la que yo tenía para aquel momento.

Creo que eso es todo. Si surge cualquier cuestión, no dudes en contactarme a mi correo (alg213@alumnos.unican.es).

Un saludo,
Álvaro.